//Margarita Kattsyna
//CS1b - HW03
//09/22/24
//
//a program that performs a simple income tax calculation. 
//It should prompt the user for data like income, expense, deductions, etc, //and calculate the income tax for a given year.
