//CS1B 
//Margarita Kattsyna
//HW01
////The program outputs the number of miles the automobile can be driven without recharging.

#include <iostream>
using namespace std;

