//Margarita Kattsyna
//CS1b - HW04
//10/03/24
//Matrix Addition, Subtraction, & Multiplication

#ifndef hw04_H
#define hw04_H
#include <iostream>
using namespace std;

const int SIZE = 2;

void add(double[SIZE][SIZE], double[SIZE][SIZE], double[SIZE][SIZE], int);
void sub(double[SIZE][SIZE], double[SIZE][SIZE], double[SIZE][SIZE], int);
void mul(double[SIZE][SIZE], double[SIZE][SIZE], double[SIZE][SIZE], int);

#endif