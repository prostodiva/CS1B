#include "hw02.hpp"

int smallCups = 0;
int mediumCups = 0;
int largeCups = 0;
double totalAmount = 0;
int coffeeSold = 0;

void printTheData() {

	cout <<"Small cup count: "<<smallCups<<endl;
	cout <<"Medium cup count: "<<mediumCups<<endl;
	cout <<"Large cup count: "<<largeCups<<endl;
	cout <<"Total amount of coffee sold: "<<coffeeSold<<endl;
	cout <<"Total money made: "<<totalAmount<<endl;

}
