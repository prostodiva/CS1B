#include "hw02.hpp"

void showMoneyMade() {

    cout << "\nTotal money made: "<<totalAmount<<endl;

}
