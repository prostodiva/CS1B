#include "hw02.hpp"

void showCoffeeSold() {
	
	cout << "Total amount of coffee sold: " <<coffeeSold<<" OZ"<<endl;
}
