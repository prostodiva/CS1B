#include "hw02.hpp"

void userMenu() {

	cout <<"\nEnter 1 to order coffee." <<endl;
	cout <<"Enter 2 to check the total money made up to this time."<<endl;
	cout <<"Enter 3 to check the total amount of coffee sold up to this time."<<endl;
	cout <<"Enter 4 to check the number of cups of coffee of each size sold."<<endl;
	cout <<"Enter 5 to print the data." <<endl;
	cout <<"Enter 6 to exit the program.\n" <<endl;

}

