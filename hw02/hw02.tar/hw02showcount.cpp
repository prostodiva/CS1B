#include "hw02.hpp"


void showCupCount() {
	
	cout <<"Small cup count: "<<smallCups<<endl;
	cout <<"Medium cup count: "<<mediumCups<<endl;
	cout <<"Large cup count: "<<largeCups<<endl;
	
	}


